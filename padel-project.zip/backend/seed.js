// seed.js — run once to populate demo data
// Usage: node seed.js

require('dotenv').config();
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const User = require('./models/User');
const Tournament = require('./models/Tournament');
const Match = require('./models/Match');
const Registration = require('./models/Registration');
const PointsHistory = require('./models/PointsHistory');

const seed = async () => {
  await mongoose.connect(process.env.MONGO_URI);
  console.log('Connected to MongoDB');

  // Clear existing data
  await Promise.all([
    User.deleteMany({}),
    Tournament.deleteMany({}),
    Match.deleteMany({}),
    Registration.deleteMany({}),
    PointsHistory.deleteMany({}),
  ]);
  console.log('Cleared existing data');

  // Create users
  const hash = pw => bcrypt.hashSync(pw, 10);
  const users = await User.insertMany([
    { name: 'Admin User',    email: 'admin@padel.com',  password: hash('admin'), role: 'admin',  points: 0 },
    { name: 'Carlos Ruiz',   email: 'carlos@padel.com', password: hash('123'),   role: 'player', points: 1450 },
    { name: 'Sofia Martin',  email: 'sofia@padel.com',  password: hash('123'),   role: 'player', points: 820 },
    { name: 'Ahmed Hassan',  email: 'ahmed@padel.com',  password: hash('123'),   role: 'player', points: 380 },
    { name: 'Lena Müller',   email: 'lena@padel.com',   password: hash('123'),   role: 'player', points: 1100 },
    { name: 'Marco Ferrari', email: 'marco@padel.com',  password: hash('123'),   role: 'player', points: 650 },
    { name: 'Yasmin Torres', email: 'yasmin@padel.com', password: hash('123'),   role: 'player', points: 210 },
    { name: 'Jake Wilson',   email: 'jake@padel.com',   password: hash('123'),   role: 'player', points: 1580 },
    { name: 'Priya Singh',   email: 'priya@padel.com',  password: hash('123'),   role: 'player', points: 490 },
  ]);
  console.log(`Created ${users.length} users`);

  const [admin, carlos, sofia, ahmed, lena, marco, yasmin, jake, priya] = users;

  // Create tournaments
  const tournaments = await Tournament.insertMany([
    { name: 'Spring Open',       category: 'Beginner', date: '2026-03-15', status: 'completed' },
    { name: 'City Championship', category: 'D',        date: '2026-04-01', status: 'active' },
    { name: 'Elite Masters',     category: 'C',        date: '2026-05-10', status: 'upcoming' },
    { name: 'Summer Slam',       category: 'Beginner', date: '2026-06-20', status: 'upcoming' },
  ]);
  console.log(`Created ${tournaments.length} tournaments`);

  const [spring, city, elite, summer] = tournaments;

  // Registrations
  await Registration.insertMany([
    // Spring Open (Beginner - completed)
    { player: ahmed._id,  tournament: spring._id },
    { player: yasmin._id, tournament: spring._id },
    { player: priya._id,  tournament: spring._id },
    // City Championship (D - active)
    { player: sofia._id,  tournament: city._id },
    { player: lena._id,   tournament: city._id },
    { player: marco._id,  tournament: city._id },
    { player: jake._id,   tournament: city._id },
    // Elite Masters (C - upcoming)
    { player: carlos._id, tournament: elite._id },
    { player: jake._id,   tournament: elite._id },
  ]);
  console.log('Created registrations');

  // Matches for Spring Open
  const m1 = await Match.create({ tournament: spring._id, player1: ahmed._id,  player2: yasmin._id, winner: ahmed._id,  round: 'quarter' });
  const m2 = await Match.create({ tournament: spring._id, player1: priya._id,  player2: ahmed._id,  winner: ahmed._id,  round: 'semi' });
  const m3 = await Match.create({ tournament: spring._id, player1: ahmed._id,  player2: priya._id,  winner: ahmed._id,  round: 'final' });

  // Matches for City Championship
  const m4 = await Match.create({ tournament: city._id, player1: sofia._id, player2: marco._id, winner: sofia._id, round: 'quarter' });
  const m5 = await Match.create({ tournament: city._id, player1: lena._id,  player2: jake._id,  winner: lena._id,  round: 'quarter' });
  console.log('Created matches');

  // Points history for Spring Open (completed)
  await PointsHistory.insertMany([
    { player: ahmed._id,  points: 60,  reason: 'Quarter-final — Spring Open', tournament: spring._id, date: '2026-03-15' },
    { player: yasmin._id, points: 0,   reason: 'Quarter-final — Spring Open', tournament: spring._id, date: '2026-03-15' },
    { player: ahmed._id,  points: 120, reason: 'Semi-final — Spring Open',    tournament: spring._id, date: '2026-03-15' },
    { player: priya._id,  points: 60,  reason: 'Semi-final — Spring Open',    tournament: spring._id, date: '2026-03-15' },
    { player: ahmed._id,  points: 300, reason: 'Winner — Spring Open',        tournament: spring._id, date: '2026-03-15' },
    { player: priya._id,  points: 200, reason: 'Finalist — Spring Open',      tournament: spring._id, date: '2026-03-15' },
  ]);
  console.log('Created points history');

  console.log('\n✅ Seed complete! Demo accounts:');
  console.log('  Admin:    admin@padel.com  / admin');
  console.log('  Player C: carlos@padel.com / 123');
  console.log('  Player D: sofia@padel.com  / 123');
  console.log('  Beginner: ahmed@padel.com  / 123');

  await mongoose.disconnect();
};

seed().catch(err => { console.error(err); process.exit(1); });
