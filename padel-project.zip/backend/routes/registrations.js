const express = require('express');
const router = express.Router();
const Registration = require('../models/Registration');
const Tournament = require('../models/Tournament');
const User = require('../models/User');
const auth = require('../middleware/auth');

function getCategory(points) {
  if (points >= 1200) return 'C';
  if (points >= 500) return 'D';
  return 'Beginner';
}

// GET /api/registrations?tournament=id
router.get('/', async (req, res) => {
  try {
    const filter = {};
    if (req.query.tournament) filter.tournament = req.query.tournament;
    if (req.query.player) filter.player = req.query.player;
    const regs = await Registration.find(filter)
      .populate('player', 'name email points')
      .populate('tournament', 'name category date status');
    res.json(regs);
  } catch (err) {
    res.status(500).json({ message: 'Server error' });
  }
});

// POST /api/registrations — register current user
router.post('/', auth, async (req, res) => {
  try {
    const { tournamentId } = req.body;
    const tournament = await Tournament.findById(tournamentId);
    if (!tournament) return res.status(404).json({ message: 'Tournament not found' });
    if (tournament.status !== 'upcoming')
      return res.status(400).json({ message: 'Registration is closed for this tournament' });

    const user = await User.findById(req.user.id);
    const playerCat = getCategory(user.points);
    const order = ['Beginner', 'D', 'C'];
    if (order.indexOf(playerCat) > order.indexOf(tournament.category))
      return res.status(400).json({ message: `${playerCat} players cannot join ${tournament.category} tournaments` });

    const existing = await Registration.findOne({ player: req.user.id, tournament: tournamentId });
    if (existing) return res.status(400).json({ message: 'Already registered' });

    const reg = await Registration.create({ player: req.user.id, tournament: tournamentId });
    await reg.populate('tournament', 'name category date');
    res.status(201).json(reg);
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

// DELETE /api/registrations/:id — cancel your own registration (upcoming tournaments only)
router.delete('/:id', auth, async (req, res) => {
  try {
    const reg = await Registration.findById(req.params.id).populate('tournament');
    if (!reg)
      return res.status(404).json({ message: 'Registration not found.' });

    if (reg.player.toString() !== req.user.id)
      return res.status(403).json({ message: 'You can only cancel your own registration.' });

    if (reg.tournament?.status !== 'upcoming')
      return res.status(400).json({ message: 'Cannot cancel registration after the tournament has started.' });

    await reg.deleteOne();
    res.json({ message: 'Registration cancelled successfully.' });
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

module.exports = router;
